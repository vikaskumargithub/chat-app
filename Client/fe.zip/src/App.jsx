import './index.css';
import { Signup } from './components/Signup';

function App() {
 return <div>
  <div>
   <Signup/>
  </div>
 </div>
}

export default App
